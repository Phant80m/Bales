#ifndef __TRACYMEMORY_HPP__
#define __TRACYMEMORY_HPP__

#include <stdlib.h>

namespace tracy
{

extern size_t memUsage;

}

#endif
