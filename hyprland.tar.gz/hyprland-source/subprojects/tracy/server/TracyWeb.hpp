#ifndef __TRACYWEB_HPP__
#define __TRACYWEB_HPP__

namespace tracy
{

void OpenWebpage( const char* url );

}

#endif
