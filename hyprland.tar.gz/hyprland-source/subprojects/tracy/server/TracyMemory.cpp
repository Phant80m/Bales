#include "TracyMemory.hpp"

namespace tracy
{

size_t memUsage = 0;

}
