use url::Url;
mod updater;
pub struct Updater {
    pub url: Url,
}
